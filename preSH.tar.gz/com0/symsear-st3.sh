lua bit-dec-c.lua < comp/code.tar.stab.data.bit > comp/code.tar.stab.data
lua bit-dec-c.lua < comp/code.tar.data.bit > comp/code.tar.data
lua symsear-tlt.lua `wc -c < code.tar` `wc -c < comp/code.tar.stab` < comp/code.tar.stab.stab > inst.lua
