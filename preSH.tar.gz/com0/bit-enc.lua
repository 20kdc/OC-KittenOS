-- useful stuff -> bitstream
while true do
 local p = io.read(1)
 if not p then return end
 p = p:byte()
 for i = 0, 7 do
  if ((1 << i) & p) ~= 0 then
   io.write("1")
  else
   io.write("0")
  end
 end
end
