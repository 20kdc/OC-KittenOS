lua symsear.lua norm comp/code.tar < code.tar
