-- bitstream -> useful stuff
local running = true
while running do
 local b = 0
 for i = 0, 7 do
  local p = io.read(1)
  if not p then
   running = false
   p = " "
  end
  if p == "1" then
   b = b + (1 << i)
  end
 end
 io.write(string.char(b))
end
