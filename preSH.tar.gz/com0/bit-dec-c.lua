-- bitstream -> useful stuff
local running = true
local n = 0
while running do
 local b = 0
 for i = 0, 7 do
  local p = io.read(1)
  if not p then
   if i == 0 then return end
   running = false
   p = " "
  end
  if p == "1" then
   b = b + (1 << i)
  end
 end
 b = (b + n) % 256
 n = n + 3
 io.write(string.char(b))
end
