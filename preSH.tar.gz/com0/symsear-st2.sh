lua symsear.lua stab comp/code.tar.stab < comp/code.tar.stab
./symsear-st3.sh
