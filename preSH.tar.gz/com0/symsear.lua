-- Symsear prototype
-- SYMBOL SEARCH FOR UTFLIKE ENCODING
local LEVELS = 2
local SUITABILITYT = 2
local minsym, maxsym, pbc2 = 2, 24, 11

-- BC2 encoder parameter must match decoder

local profile, x = ...
if profile == "stab" then
 LEVELS = 4
 SUITABILITYT = 6
 maxsym = 9
 pbc2 = 10
elseif profile ~= "norm" then
 error("no such profile")
end

local s = io.read("*a")

local potentialSyms = {}

for i = 1, #s do
 for l = minsym, maxsym do
  local sym = s:sub(i, i + l - 1)
  if #sym == l then
   potentialSyms[sym] = (potentialSyms[sym] or 0) + ((#sym) * (#sym))
  end
 end
end

local killList = {}
local vTotal, vCount = 0, 0
for k, v in pairs(potentialSyms) do
 if v <= (maxsym * maxsym * SUITABILITYT) then
  if SUITABILITYT > 0 then
   table.insert(killList, k)
  end
 end
 vTotal = vTotal + v
 vCount = vCount + 1
end
for _, v in ipairs(killList) do
 potentialSyms[v] = nil
end

io.stderr:write("KLC, avg was " .. (vTotal / vCount) ..  "\n")

local listings = {}
for k, v in pairs(potentialSyms) do
 --io.stderr:write("\"" .. k .. "\" // " .. v .. "\n")
 table.insert(listings, k)
end

for i = 0, 255 do
 local st = string.char(i)
 if not potentialSyms[st] then
  table.insert(listings, st)
 end
end

io.stderr:write("performing symbol pathfinding (" .. #listings .. ") ...\n")

local function symPF(syx, levels)
 if levels <= 1 then return nil, 0 end
 local bestScore = 0
 local rv
 for k, v in ipairs(listings) do
  if syx:sub(1, #v) == v then
   local score = #v / (#utf8.char(k))
   local _, asc = symPF(syx:sub(#v + 1), levels - 1)
   score = score + asc
   if score >= bestScore then
    bestScore = score
    rv = k
   end
  end
 end
 return rv, bestScore
end

-- Consumes s to finish
local listingUsed = {}
local stream = {}
while #s > 0 do
 io.stderr:write((#s) .. "\n")
 local nxt, sc = symPF(s, LEVELS)
 if nxt then
  listingUsed[nxt] = (listingUsed[nxt] or 0) + 1
  table.insert(stream, nxt)
  s = s:sub(#(listings[nxt]) + 1)
 else
  error("Impossible!")
 end
end

-- Translate things...
local finListings1 = {}
for k, v in ipairs(listings) do
 if listingUsed[k] then
  local pos = (#finListings1) + 1
  for i = 1, #finListings1 do
   if listingUsed[finListings1[i]] < listingUsed[k] then
    pos = i
    break
   end
  end
  table.insert(finListings1, pos, k)
 end
end

local finListings = {}
local translateTbl = {}
for k, v in ipairs(finListings1) do
 finListings[k] = listings[v]
 translateTbl[v] = k
end

io.stderr:write("syms " .. #listings .. " missing " .. #killList .. " of which " .. #finListings .. " used, stream with " .. #stream .. " tokens\n")

local stabf1 = io.open(x .. ".stab", "wb")
local stabf2 = io.open(x .. ".data.bit", "wb")

for k, v in ipairs(finListings) do
 stabf1:write(utf8.char(#v) .. v)
end
for _, v in ipairs(stream) do
 -- 6-bit or 13-bit + 1 head
 local v2 = translateTbl[v]
 local bc = 6
 if v2 >= (1 << bc) then
  v2 = v2 - (1 << bc)
  stabf2:write("1")
  bc = pbc2
 else
  stabf2:write("0")
 end
 if v2 >= (1 << bc) then error("OOB " .. v2) end
 for i = 1, bc do
  if ((1 << (i - 1)) & v2) ~= 0 then
   stabf2:write("1")
  else
   stabf2:write("0")
  end
 end
end
