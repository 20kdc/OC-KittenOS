-- CONQUER

local all = io.read("*a")

local function count(p, sets)
 if p == "" then error("WTF") end
 local precursor = sets[p:sub(1, #p - 1)]
 local set = sets[precursor]
 local nset = {}
 sets[p] = nset
 if set then
  -- magical optimization version!
  local c = 0
  for k, _ in pairs(set) do
   if all:sub(k, k + #p - 1) == p then
    nset[k] = true
    c = c + 1
   end
  end
  return c
 end
 -- nope, take the long path
 local li = 1
 local c = 0
 while true do
  local ni = all:find(p, li, true)
  if not ni then
   return c
  end
  nset[ni] = true
  li = ni + #p
  c = c + 1
 end
end
local function repl(src, p, b)
 if a == "" then error("WTF") end
 local li = 1
 local dst = ""
 local c = 0
 while true do
  local ni = src:find(p, li, true)
  if not ni then
   return dst .. src:sub(li), c
  end
  dst = dst .. src:sub(li, ni - 1) .. b
  li = ni + #p
  c = c + 1
 end
end

local function dprint(...)
 io.stderr:write(...)
 io.stderr:write("\n")
 io.stderr:flush()
end

dprint("at", #all)
-- Look for 127 substrings.
for i = 0, 127 do
 local bestI = 0
 local bestL = 0
 local bestLC = 0
 local allSets = {}
 for l = 2, 8 do
  -- quick patch to check perf.comp: add dprint
  dprint("subpass ", l)
  for idxA = 1, #all + 1 - l do
   local pat = all:sub(idxA, idxA + l - 1)
   local c = count(pat, allSets)
   local lc = ((c - 1) * l) - 1
   if bestLC < lc then
    bestI = idxA
    bestL = l
    bestLC = lc
   end
  end
 end
 if bestI == 0 then
  all = "\x00" .. all
 else
  dprint(bestI, bestL, bestLC)
  local pat = all:sub(bestI, bestI + bestL - 1)
  all = repl(all, pat, string.char(128 + i))
  all = string.char(#pat) .. pat .. all
 end
 dprint("down to", #all)
end
io.write(all)
