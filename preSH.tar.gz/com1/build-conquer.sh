ldc -O5 -boundscheck=off conquer.d
