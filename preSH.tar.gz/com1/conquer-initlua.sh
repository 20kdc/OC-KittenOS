time sudo chrt 20 ./conquer < ../code/init.lua > init.lua.conquer
