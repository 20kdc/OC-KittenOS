cd ..
rm code.tar
tar -cf code.tar code
cd newcom
lua preproc.lua < ../code.tar > code.tar.pp
time sudo chrt 20 ./conquer < code.tar.pp > code.tar.conquer
