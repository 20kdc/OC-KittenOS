-- PREPROC: preprocess input
while true do
 local c = io.read(1)
 if not c then return end
 local bc = c:byte()
 if bc < 127 then
  io.write(c)
 else
  if bc < 253 then
   io.write("\x7F" .. string.char(bc - 127))
  else
   io.write("\x7F\x7F" .. string.char(bc - 253))
  end
 end
end
